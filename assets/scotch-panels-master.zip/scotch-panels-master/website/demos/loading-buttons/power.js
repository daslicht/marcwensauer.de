$(function() {

    $('.scotch-button span.loader').scotchPanel({
        'containerSelector': 'button'
    });

});