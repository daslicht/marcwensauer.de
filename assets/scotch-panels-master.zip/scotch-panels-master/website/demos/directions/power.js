$(function() {

    $('.one-of-many').scotchPanel({
        clickSelector: '.toggle-panels',
        containerSelector: '.panel-container', // Selects the nearest matching container
    });

});