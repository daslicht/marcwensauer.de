$(function() {

    $('.scotch-panel').scotchPanel({
        containerSelector: '#super-container',
        distanceX: '30%'
    });

});